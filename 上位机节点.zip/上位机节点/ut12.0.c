#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <termios.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/select.h>
#include <time.h>
#include <errno.h>

#define BUFFER_SIZE 256
#define FEED_INTERVAL (5 * 3600) // 5小时喂食间隔（秒）

// 语音指令队列
typedef struct {
    char commands[32];  // 指令缓冲区
    int head;           // 队列头
    int tail;           // 队列尾
    pthread_mutex_t lock; // 互斥锁
} CommandQueue;

typedef struct {
    float temperature;  // 温度
    float ph;           // PH值
    int tds;            // 溶解固体含量
    float water_level;  // 水位
} AquariumData;

// 串口设备结构
typedef struct {
    int fd;             // 文件描述符
    char name[20];      // 设备名称
    pthread_t thread_id;// 线程ID
    CommandQueue* queue;// 指令队列指针
    pthread_mutex_t write_lock; // 串口写锁
} SerialPort;

// 全局设备
SerialPort voice_port;  // ttyS2 - 语音输入
SerialPort main_port;   // ttyS3 - 主串口
AquariumData sensor_data = {0};
char status_string[5] = "0000"; // 状态字符串: [光照][TDS][水位][语音指令]

// 喂食控制变量
int feeding = 0;                // 喂食状态标志
time_t feed_start_time = 0;     // 喂食开始时间
pthread_mutex_t feed_lock;      // 喂食状态互斥锁
int feed_duration = 5;          // 喂食持续时间（秒）
pthread_mutex_t feed_duration_lock; // 喂食持续时间锁

// 初始化命令队列
void queue_init(CommandQueue* q) {
    q->head = q->tail = 0;
    pthread_mutex_init(&q->lock, NULL);
}

// 添加命令到队列
void queue_push(CommandQueue* q, char cmd) {
    pthread_mutex_lock(&q->lock);
    q->commands[q->tail] = cmd;
    q->tail = (q->tail + 1) % sizeof(q->commands);
    pthread_mutex_unlock(&q->lock);
}

// 从队列获取命令（返回0表示无命令）
char queue_pop(CommandQueue* q) {
    char cmd = 0;
    pthread_mutex_lock(&q->lock);
    if(q->head != q->tail) {
        cmd = q->commands[q->head];
        q->head = (q->head + 1) % sizeof(q->commands);
    }
    pthread_mutex_unlock(&q->lock);
    return cmd;
}

void process_single_data(const char* data) {
    float value;
    int int_value;
    static time_t last_alert_time = 0; // 上次报警时间

    // 解析传感器数据
    if(sscanf(data, "T:%f", &value) == 1) {
        sensor_data.temperature = value;
        printf("更新温度: %.1f℃\n", value);
    }
    else if(sscanf(data, "P:%f", &value) == 1) {
        sensor_data.ph = value;
        status_string[0] = (sensor_data.ph >4000) ? '1' : '0';
        printf("更新光照值: %.1f, 状态: %c\n", value, status_string[0]);
    }
    else if(sscanf(data, "S:%d", &int_value) == 1) {
        sensor_data.tds = int_value;
        status_string[1] = (sensor_data.tds > 300) ? '1' : '0';
        printf("更新TDS: %dppm, 状态: %c\n", int_value, status_string[1]);
    }
    else if(sscanf(data, "L:%f", &value) == 1) {
        sensor_data.water_level = value;
        status_string[2] = (sensor_data.water_level > 3000) ? '1' : '0';
        printf("更新水位: %.1fcm, 状态: %c\n", value, status_string[2]);
    }
   
    else {
        printf("无法识别的数据: %s\n", data);
    }
}

// 初始化串口 - 修复版本
int uart_init(const char* port_name, int baud_rate) {
    int uart_fd = open(port_name, O_RDWR | O_NOCTTY);
    if(uart_fd < 0) {
        perror("无法打开串口");
        return -1;
    }

    struct termios options;
    tcgetattr(uart_fd, &options);
    
    // 配置串口参数
    cfsetispeed(&options, baud_rate);
    cfsetospeed(&options, baud_rate);
    options.c_cflag |= (CLOCAL | CREAD | CS8);
    options.c_cflag &= ~(PARENB | CSTOPB | CRTSCTS);
    options.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);
    options.c_iflag &= ~(IXON | IXOFF | IXANY);

    // 设置读取参数 - 阻塞模式
    options.c_cc[VTIME] = 10; // 1秒超时
    options.c_cc[VMIN]  = 0;  // 最小读取0字节

    if(tcsetattr(uart_fd, TCSANOW, &options) != 0) {
        perror("串口配置失败");
        close(uart_fd);
        return -1;
    }
    
    // 清空缓冲区
    tcflush(uart_fd, TCIOFLUSH);
    
    printf("串口 %s 初始化成功 (波特率: %d)\n", port_name, baud_rate);
    return uart_fd;
}

// 启动喂食流程
void start_feeding() {
    pthread_mutex_lock(&feed_lock);
    
    if (!feeding) {
        printf("[喂食控制] 启动喂食\n");
        feeding = 1;
        feed_start_time = time(NULL);
        // 更新状态为开始喂食
        status_string[3] = 'g';
    }
    
    pthread_mutex_unlock(&feed_lock);
}

// 停止喂食
void stop_feeding() {
    pthread_mutex_lock(&feed_lock);
    
    if (feeding) {
        printf("[喂食控制] 停止喂食\n");
        feeding = 0;
        // 更新状态为停止喂食
        status_string[3] = 'h';
    }
    
    pthread_mutex_unlock(&feed_lock);
}

// 喂食控制线程
void* feeding_thread(void* arg) {
    CommandQueue* queue = (CommandQueue*)arg;
    
    printf("[喂食线程] 启动，每 %d 小时自动喂食\n", FEED_INTERVAL/3600);
    
    while(1) {
        sleep(FEED_INTERVAL); // 等待5小时
        
        // 获取当前喂食持续时间
        pthread_mutex_lock(&feed_duration_lock);
        int duration = feed_duration;
        pthread_mutex_unlock(&feed_duration_lock);
        
        printf("[喂食线程] 定时喂食启动 (持续时间: %d秒)\n", duration);
        start_feeding();
        queue_push(queue, 'g'); // 发送开始喂食指令
        
        // 等待喂食完成
        sleep(duration);
        
        printf("[喂食线程] 定时喂食结束\n");
        stop_feeding();
        queue_push(queue, 'h'); // 发送停止喂食指令
    }
    return NULL;
}

// ttyS2 语音指令接收线程
void* voice_thread(void* arg) {
    SerialPort* port = (SerialPort*)arg;
    char buffer[BUFFER_SIZE];
    int bytes_read;
    
    printf("[%s] 语音接收线程启动...\n", port->name);
    
    while(1) {
        bytes_read = read(port->fd, buffer, BUFFER_SIZE-1);
        if(bytes_read > 0) {
            buffer[bytes_read] = '\0';
            
            // 提取有效指令 (a-h)
            for(int i = 0; i < bytes_read; i++) {
                if(buffer[i] >= 'a' && buffer[i] <= 'z') {
                    printf("[语音指令] 收到: %c\n", buffer[i]);
                    queue_push(port->queue, buffer[i]);
                    // 更新语音指令位
                    status_string[3] = buffer[i];
                }
            }
        } else if (bytes_read < 0) {
            perror("语音串口读取错误");
        }
        usleep(100000); // 100ms处理间隔
    }
    return NULL;
}

// 主串口处理线程 - 简化版本
void* main_port_thread(void* arg) {
    SerialPort* port = (SerialPort*)arg;
    char buffer[BUFFER_SIZE];
    char line_buffer[1024] = {0};
    int line_index = 0;
    time_t last_status_time = 0;
    int feed_stop_needed = 0; // 标记是否需要发送停止喂食指令
    int bytes_read;
    
    printf("[%s] 主串口线程启动...\n", port->name);
    
    while(1) {
        // 处理接收数据
        bytes_read = read(port->fd, buffer, BUFFER_SIZE-1);
        if(bytes_read > 0) {
            buffer[bytes_read] = '\0';
            printf("[主串口接收] 原始数据: %s\n", buffer); // 调试输出
            
            // 处理每个字符
            for(int i = 0; i < bytes_read; i++) {
                if(buffer[i] == '\n' || buffer[i] == '\r') {
                    // 完整行处理
                    if(line_index > 0) {
                        line_buffer[line_index] = '\0';
                        printf("[主串口接收] 完整行: %s\n", line_buffer);
                        process_single_data(line_buffer);
                        line_index = 0;
                    }
                } else {
                    // 添加到行缓冲区
                    if(line_index < sizeof(line_buffer)-1) {
                        line_buffer[line_index++] = buffer[i];
                    } else {
                        // 缓冲区溢出，重置
                        printf("警告: 行缓冲区溢出\n");
                        line_index = 0;
                    }
                }
            }
        } else if (bytes_read < 0) {
            perror("主串口读取错误");
        }
        
        // 检查是否需要停止喂食
        pthread_mutex_lock(&feed_lock);
        if(feeding) {
            time_t now = time(NULL);
            pthread_mutex_lock(&feed_duration_lock);
            int duration = feed_duration;
            pthread_mutex_unlock(&feed_duration_lock);
            
            if(now - feed_start_time >= duration) {
                printf("[喂食控制] 喂食时间结束，需要发送停止指令\n");
                feed_stop_needed = 1;
                feeding = 0; // 立即更新喂食状态
                status_string[3] = 'h'; // 更新状态为停止喂食
            }
        }
        pthread_mutex_unlock(&feed_lock);
        
        // 处理语音指令队列
        char cmd = queue_pop(port->queue);
        if(cmd) {
            printf("[指令转发] %c → %s\n", cmd, port->name);
            
            // 处理喂食指令
            if(cmd == 'g') {
                start_feeding();
            } else if(cmd == 'h') {
                stop_feeding();
            }
            // 处理喂食时间调整指令
            else if(cmd == 'e' || cmd == 'f' || cmd == 'l') {
                int new_duration = 0;
                switch(cmd) {
                    case 'e': new_duration = 5; break;
                    case 'f': new_duration = 10; break;
                    case 'l': new_duration = 15; break;
                }
                
                pthread_mutex_lock(&feed_duration_lock);
                feed_duration = new_duration;
                pthread_mutex_unlock(&feed_duration_lock);
                
                printf("[喂食设置] 喂食时间已设置为 %d 秒\n", new_duration);
                
                // 发送确认消息
                char ack_msg[32];
                snprintf(ack_msg, sizeof(ack_msg), "FeedTime:%d\n", new_duration);
                pthread_mutex_lock(&port->write_lock);
                write(port->fd, ack_msg, strlen(ack_msg));
                pthread_mutex_unlock(&port->write_lock);
            }
            
            // 发送指令给下位机
            pthread_mutex_lock(&port->write_lock);
            write(port->fd, &cmd, 1);
            pthread_mutex_unlock(&port->write_lock);
        }
        
        // 处理自动停止喂食请求
        if(feed_stop_needed) {
            printf("[喂食控制] 发送停止喂食指令\n");
            char stop_cmd = 'h';
            pthread_mutex_lock(&port->write_lock);
            write(port->fd, &stop_cmd, 1);
            pthread_mutex_unlock(&port->write_lock);
            feed_stop_needed = 0;
        }
        
        // 每秒发送一次状态字符串
        time_t now = time(NULL);
        if(now - last_status_time >= 1) {
            // 构建并发送状态字符串
            char status_str[6];
            snprintf(status_str, sizeof(status_str), "%s\n", status_string);
            
            pthread_mutex_lock(&port->write_lock);
            write(port->fd, status_str, strlen(status_str));
            pthread_mutex_unlock(&port->write_lock);
            
            printf("发送状态: %s\n", status_string);
            last_status_time = now;
        }
        
        usleep(100000); // 100ms处理间隔
    }
    return NULL;
}

// 主函数
int main() {
    CommandQueue cmd_queue;
    queue_init(&cmd_queue);
    pthread_mutex_init(&feed_lock, NULL);
    pthread_mutex_init(&feed_duration_lock, NULL);
    pthread_mutex_init(&voice_port.write_lock, NULL);
    pthread_mutex_init(&main_port.write_lock, NULL);
    
    // 初始化状态字符串
    strcpy(status_string, "0000"); // 默认状态
    
    // 初始化语音串口 (ttyS2)
    strcpy(voice_port.name, "/dev/ttyS2");
    voice_port.fd = uart_init(voice_port.name, B115200);
    voice_port.queue = &cmd_queue;
    
    // 初始化主串口 (ttyS3)
    strcpy(main_port.name, "/dev/ttyS3");
    main_port.fd = uart_init(main_port.name, B115200);
    main_port.queue = &cmd_queue;
    
    if(voice_port.fd < 0 || main_port.fd < 0) {
        if(voice_port.fd >= 0) close(voice_port.fd);
        if(main_port.fd >= 0) close(main_port.fd);
        return 1;
    }
    
    // 创建语音指令接收线程
    if(pthread_create(&voice_port.thread_id, NULL, voice_thread, &voice_port) != 0) {
        perror("语音线程创建失败");
        close(voice_port.fd);
        close(main_port.fd);
        return 1;
    }
    
    // 创建主串口处理线程
    if(pthread_create(&main_port.thread_id, NULL, main_port_thread, &main_port) != 0) {
        perror("主串口线程创建失败");
        close(voice_port.fd);
        close(main_port.fd);
        return 1;
    }
    
    // 创建自动喂食线程
    pthread_t feed_thread;
    if(pthread_create(&feed_thread, NULL, feeding_thread, &cmd_queue) != 0) {
        perror("喂食线程创建失败");
        close(voice_port.fd);
        close(main_port.fd);
        return 1;
    }
    
    printf("系统已启动，等待语音指令 (a-h)...\n");
    printf("自动喂食已启用，每 %d 小时喂食一次\n", FEED_INTERVAL/3600);
    printf("当前喂食持续时间: %d 秒\n", feed_duration);
    
    // 主线程监控
    while(1) {
        sleep(1);
        static int counter = 0;
        
        // 心跳显示
        if(++counter % 10 == 0) {
            printf("系统运行中... 当前状态: %s\n", status_string);
            pthread_mutex_lock(&feed_lock);
            if(feeding) {
                pthread_mutex_lock(&feed_duration_lock);
                int duration = feed_duration;
                pthread_mutex_unlock(&feed_duration_lock);
                
                time_t remaining = duration - (time(NULL) - feed_start_time);
                if(remaining > 0) {
                    printf("喂食进行中，剩余时间: %ld 秒\n", remaining);
                }
            }
            pthread_mutex_unlock(&feed_lock);
        }
    }
    
    // 清理资源（通常不会执行到这里）
    pthread_join(voice_port.thread_id, NULL);
    pthread_join(main_port.thread_id, NULL);
    pthread_join(feed_thread, NULL);
    close(voice_port.fd);
    close(main_port.fd);
    pthread_mutex_destroy(&feed_lock);
    pthread_mutex_destroy(&feed_duration_lock);
    pthread_mutex_destroy(&voice_port.write_lock);
    pthread_mutex_destroy(&main_port.write_lock);
    
    return 0;
}
