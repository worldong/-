#include "ls1x.h"
#include "test.h"
#include "ls1x_latimer.h"
#include "AllCtrl.h"
#include "ls1c102_adc.h"
uint16_t PH_GetData()//采用ADC1
{
    int32_t Data=0,i;
    for(i=0;i<10;i++)
    {
        Data+=Adc_Measure(ADC_CHANNEL_I1);   
        delay_ms(5);
    }
    // Data/=10;
    // Data = (Data*3/4096);
    // Data = Data*(-6)+17;
    
    // if(Data>14)
    // {Data=14;}
    // if(Data<0)
    // {Data=0;}
    return Data;
}
int TDS_Get_ppm()//采用ADC6(GPIO16 - AO)
{
    unsigned short value;
    value = Adc_Measure(ADC_CHANNEL_I6);        // ADC电压采集  单位：hao伏
    value=(67)*value*value*value/1000000000-(128)*value*value/1000000+428*value/1000;
    if (value<20)
     {
         value=0;
     }
     return value;
}
uint16_t WATER_GetData()//采用ADC5(GPIO15)
{
    uint32_t Data=0,i;
    for(i=0;i<10;i++)
    {
        Data+=Adc_Measure(ADC_CHANNEL_I4);   
        delay_ms(5);
    }
    Data/=10;
    return Data;
}
uint16_t LDR_GetData()
{
    uint32_t Data=0,i;
    for(i=0;i<10;i++)
    {
        Data+=Adc_Measure(ADC_CHANNEL_I7);   
        delay_ms(5);
    }
    Data/=10;
    return Data;
}
