#include "ls1x.h"
#include "Config.h"
#include "ls1x_gpio.h"
#include "ls1x_latimer.h"
#include "esp8266.h"
#include "ls1c102_interrupt.h"
#include "iic1.h"
#include "oled.h"
#include "dht11.h"
#include "BEEP.h"
#include "key.h"
#include "led.h"
#include "ls1x_printf.h"
#include "ls1x_uart.h"
#include "ls1x_clock.h"
#include <stdlib.h>
#include "ls1x_string.h"
#include "UserGpio.h"
#include "led.h"
#include "queue.h"
#include "ls1c102_adc.h"
#include "AllCtrl.h"

extern uint8_t Read_Buffer[300];
extern uint8_t Read_Buffer_2[300];
extern LedState leds[MAX_LEDS];
unsigned short value;
unsigned short tdsvalue;
unsigned short watervalue;
unsigned short phvalue;
unsigned short ldrvalue;
int waterflag_y,turn_flag;
extern int waterflag_x;

#define LED 20
extern int pwm_cmp,a;
int LED_mode;
void timer_init(uint32_t msec)
{
    TIM_InitTypeDef TIM_InitStruct;
    TIM_StructInit(&TIM_InitStruct);
    TIM_InitStruct.TIME_STP =8000*msec;
    TIM_Init(&TIM_InitStruct);
}
uint8_t data[8] = {0x55, 0xAA, 0x00, 0x00, 0x00, 0x00, 0x00, 0xBB}; //温湿度数据上云平台    数据包
char temp[50];
char tds[50];
char light[50];
char water[50];
char ph[50];
char temp_2[50];
char tds_2[50];
char light_2[50];
char water_2[50];
char ph_2[50];
char str_wifi[200];
 int TDS_Get_ppm();
 uint16_t WATER_GetData();
 uint16_t LDR_GetData();
 uint16_t temperature;
 uint16_t humidity;
uint16_t PH_GetData();
 int feedFlag = 0;          // 是否喂食
 int feedEndFlag = 0;       // 喂食结束
 int feedTime = 30;               // 喂食时间
 int cacheFeedTime = 30;
 int app_cmd=0;          

int main(int arg, char *args[])
{
    SystemClockInit(); // 时钟等系统配置
    GPIOInit();        // io配置
    OLED_Init();
    EnableInt(); // 开总中断
    LED_Init();
    Uart0_init(115200); // 串口0初始化，io06 io07   串口初始化需要在开启EnableInt之后
    Uart1_init(115200);
    AFIO_RemapConfig(AFIOB, GPIO_Pin_14, 0);        // 初始化ADC通道4引脚
    AFIO_RemapConfig(AFIOB, GPIO_Pin_16, 0); 
    AFIO_RemapConfig(AFIOB, GPIO_Pin_17, 0); 
    Adc_powerOn();                                  // 打开ADC电源
    DHT11_Init();
    timer_init(2000);
    esp8266_init();

    
    while(1)
    {   
        /************************************
                一、读取并上传外设数据
         ************************************/

        //温度
        DHT11_Read_Data(&temperature, &humidity); 
        data[2] = temperature / 10;     
        sprintf(temp, "T:%2d\n", temperature / 10);
        sprintf(temp_2, "%d", temperature / 10);
        myprintf2(1,"%s", temp);              
        
        //TDS
        Adc_open(ADC_CHANNEL_I6);
        tdsvalue=TDS_Get_ppm();
        sprintf(tds, "S:%4d\n", tdsvalue); 
        sprintf(tds_2, "%d", tdsvalue);
        myprintf2(1,"%s", tds);                 

        //水位
        Adc_open(ADC_CHANNEL_I4);
        watervalue=WATER_GetData();
        sprintf(water, "L:%4d\n", watervalue);
        sprintf(water_2, "%d", watervalue);
        myprintf2(1,"%s", water);                               

        //光照
        Adc_open(ADC_CHANNEL_I7);                      
        ldrvalue=LDR_GetData();
        sprintf(light, "P:%4d\n", ldrvalue);
        sprintf(light_2, "%d", 4100-ldrvalue);
        myprintf2(1,"%s", light);   
      
        /************************************
                    二、上传云端
         ************************************/       
        sprintf(str_wifi,"{\"id\":\"123\",\"version\":\"1.0\",\"params\":{\"temp\":{\"value\":%s},\"tds\":{\"value\":%s},\"water\":{\"value\":%s},\"light\":{\"value\":%s}}}\r\n\r\n",temp_2,tds_2,water_2,light_2);
        esp8266_send_data(str_wifi);    
                   
    }


     return 0;
 }


