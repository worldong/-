#ifndef _ALLCTRL_H_
#define _ALLCTRL_H_

#include "test.h"

int TDS_Get_ppm();
uint16_t WATER_GetData();
uint16_t LDR_GetData();

#endif
