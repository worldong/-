#include "esp8266.h"
#include "Config.h"
#include "ls1x_string.h"
#include "ls1x_printf.h"
#include "ls1x_latimer.h"
#include "queue.h"
#include "led.h"
#include "ls1x_gpio.h"
#include "ls1x_uart.h"

uint8_t wifi_connected = 0;         // ESP8266 连接状态

uint8_t Read_Buffer[DATA_LEN];//设置接收缓冲数组
uint8_t Read_Buffer_2[DATA_LEN];
uint8_t Read_length;
unsigned char esp8266_buf[512];
unsigned short esp8266_cnt = 0, esp8266_cntPre = 0;

LedState leds[MAX_LEDS];
/*
    在进行esp8266试验过程中prinf对应于上位机发送
                           myprintf2(0,#fmt,..)用于发送
*/

// ESP8266 发送命令后，检测接收到的应答
// str：期待的应答结果
// 返回值：0，没有得到期待的应答结果；其他，期待应答结果的位置(str的位置)
char* esp8266_check_cmd(char *str)
{
    char *strx = NULL;

    if(Queue_isEmpty(&Circular_queue)==0)//判断队列是否为空，即判断是否收到数据
    {
        Read_length=Queue_HadUse(&Circular_queue);//返回队列中数据的长度
        {
            memset(Read_Buffer, 0, DATA_LEN);//填充接收缓冲区为0
            Queue_Read(&Circular_queue, Read_Buffer,Read_length);//读取队列缓冲区的值到接收缓冲区
            Read_Buffer[Read_length]='\0';//字符串接收结束符
            //printf("check UART0_RX_BUF:%s\r\n", Read_Buffer);// 打印正确
        }
    }
    strx = pstrstr((const char*)Read_Buffer, (const char*)str);
    return strx;
}

// 向 ESP8266 发送命令
// cmd：发送的命令字符串。
// ack：期待的应答结果，如果为空，则表示不需要等待应答
// waittime：等待时间
// 返回值：0，发送成功(得到了期待的应答结果)；1，发送失败
char esp8266_send_cmd(char *cmd, char *ack, uint16_t waittime)
{
    char res;
    //UART0_RX_STA = 0;
    //printf("cmd:%s\r\n", cmd);
    res=0;
    myprintf2(0,"%s\r\n", cmd);	//发送命令

    if(ack && waittime)		//需要等待应答
    {
        //printf("check UART0_RX_BUF:%s\r\n", Read_Buffer);// 打印正确
        while(--waittime)	//等待倒计时
        {
            delay_ms(1);
            //printf("等待倒计时\r\n");
            if(esp8266_check_cmd(ack))
            {
                printf("ack:%s\r\n", ack);
                break;//得到有效数据
            }
        }
        if(waittime == 0)
        {
            res = 1;
        }
        //else 
            //goto SEND;
        //printf("res:%d\r\n", res);
    }

    return res;
}

// Function to find a substring in a string
const char* myStrstr(const char* haystack, const char* needle) {
    if (!*needle) return haystack; // Empty needle
    for (; *haystack; ++haystack) {
        const char* h = haystack, * n = needle;
        while (*h && *n && *h == *n) {
            h++;
            n++;
        }
        if (!*n) return haystack;
    }
    return NULL;
}

// Function to copy a substring of length len from src to dest
void myStrncpy(char* dest, const char* src, size_t len) {
    while (len > 0 && *src != '\0') {
        *dest++ = *src++;
        len--;
    }
    *dest = '\0';
}
// Function to convert a string to an integer
int myAtoi(const char* str) {
    int result = 0;
    int sign = 1;
    if (*str == '-') {
        sign = -1;
        str++;
    }
    while (*str >= '0' && *str <= '9') {
        result = result * 10 + (*str - '0');
        str++;
    }
    return result * sign;
}

void esp8266_init(void)
{
    while(esp8266_send_cmd("AT+CWJAP=\"AP\",\"Zct123456\"\r\n\r\n","WIFI CONNECTED", 2000));
    memset(Read_Buffer, 0, DATA_LEN);
    while(esp8266_send_cmd("AT+MQTTUSERCFG=0,1,\"LC\",\"wc9pi11VD3\",\"version=2018-10-31&res=products%2Fwc9pi11VD3%2Fdevices%2FLC&et=1772972989&method=md5&sign=XsH40sYhwYppXV%2BTk9%2Bo7Q%3D%3D\",0,0,\"\"\r\n\r\n","OK", 2000));
    memset(Read_Buffer, 0, DATA_LEN);
    while(esp8266_send_cmd("AT+MQTTCONN=0,\"mqtts.heclouds.com\",1883,1\r\n\r\n", "OK", 2000));
    memset(Read_Buffer, 0, DATA_LEN);
}
void esp8266_send_data(char* str)
{
    while(esp8266_send_cmd("AT+MQTTSUB=0,\"$sys/wc9pi11VD3/LC/thing/property/post/reply\",1\r\n\r\n", "OK", 2000));
    memset(Read_Buffer, 0, DATA_LEN);
    while(esp8266_send_cmd("AT+MQTTPUBRAW=0,\"$sys/wc9pi11VD3/LC/thing/property/post\",200,0,0\r\n\r\n","OK", 2000));
    memset(Read_Buffer, 0, DATA_LEN);
    while(esp8266_send_cmd(str,"OK", 2000));
    memset(Read_Buffer, 0, DATA_LEN);
}
void esp8266_receive_data_1()
{
    while(esp8266_send_cmd("AT+MQTTSUB=0,\"$sys/wc9pi11VD3/LC/thing/property/set\",1\r\n\r\n", "OK", 2000));
    memset(Read_Buffer, 0, DATA_LEN);
}
int esp8266_receive_data_2()
{    
    if(Queue_isEmpty(&Circular_queue)==0)//判断队列是否为空，即判断是否收到数据
    {
        Read_length=Queue_HadUse(&Circular_queue);//返回队列中数据的长度
        {
            memset(Read_Buffer, 0, DATA_LEN);//填充接收缓冲区为0
            Queue_Read(&Circular_queue, Read_Buffer,Read_length);//读取队列缓冲区的值到接收缓冲区
            Read_Buffer[Read_length]='\0';//字符串接收结束符
        }
        return 0;
    }
    return 1;  
}
int extract_led_state(const char *str,char* led_num) {
    const char *p = str;
    // 查找"led1"字段
    while (*p) {
        if (*p == '"' && 
            p[1] == 'l' && 
            p[2] == 'e' && 
            p[3] == 'd' &&
            //p[4] == '1' && 
            (p[4] == '1'||p[4] == '2'||p[4] == '3'||p[4] == '4'||p[4] == '5'||p[4] == '6') && 
            p[5] == '"') {
            *led_num=p[4];    
            p += 6;  // 跳过"ledx"
            // 查找冒号
            while (*p && *p != ':') p++;
            if (!*p) return -1;
            p++;  // 跳过冒号
            
            // 跳过可能的空格
            while (*p == ' ' || *p == '\t' || *p == '\r' || *p == '\n') p++;
            
            // 检查true/false
            if (*p == 't' && 
                p[1] == 'r' && 
                p[2] == 'u' && 
                p[3] == 'e') {
                return 1;  // true
            }
            if (*p == 'f' && 
                p[1] == 'a' && 
                p[2] == 'l' && 
                p[3] == 's' && 
                p[4] == 'e') {
                return 0;  // false
            }
            return -1;  // 无效值
        }
        p++;
    }
    return -1;  // 未找到
}
void ESP8266_Clear(void)
{

	memset(esp8266_buf, 0, sizeof(esp8266_buf));
	esp8266_cnt = 0;

}
