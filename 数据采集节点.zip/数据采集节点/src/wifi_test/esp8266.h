#ifndef __ESP8266_H
#define __ESP8266_H

#ifdef __cplusplus
extern "C" {
#endif

#include "ls1x.h"

extern uint8_t wifi_connected;

#define MAX_LEDS 3

typedef enum {
    LED_TYPE_INT,
    LED_TYPE_STRING,
    LED_TYPE_UNKNOWN
} LedType;

typedef struct {
    LedType type;
    union {
        int intValue;
        char stringValue[50];
    } value;
} LedState;

char* esp8266_check_cmd(char *str);//ESP8266 发送命令后，检测接收到的应答
char esp8266_send_cmd(char *cmd,char *ack,uint16_t waittime);// 向 ESP8266 发送命令
void esp8266_send_data(char* str);// 向 ESP8266 发送数据
void esp8266_receive_data_1();
int esp8266_receive_data_2();//接收数据
int extract_led_state(const char *str,char* led_num);
void esp8266_init(void);
void ESP8266_Clear(void);

#ifdef __cplusplus
}
#endif

#endif
