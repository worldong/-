#ifndef _LS1X_STRING_H_
#define _LS1X_STRING_H_

#include "test.h"

// int atoi(char *pstr);
int atohex(char *str);
int strlen(const char *p);
int strcmp(const char *s1, const char *s2);
int memcmp(const void *cs, const void *ct, int count);
int memcmp2(const char *cs, const char *ct, int count);
int my_snprintf(char *str, size_t size, const char *format, ...);
// void itoa( char chWord[], int Num);
void *memcpy(void *s1, const void *s2, int n);
void *memset(void *s, int c, int count);

char *strchr(const char *s, char c);
char *strcat(char *dst, const char *src);
char *strcpy(char *dest, const char *src);
char *pstrstr(const char *haystack, const char *needle);
int strncmp(const char *s1, const char *s2, size_t n);
int my_strcmp(const char *str1, const char *str2);
INT8U strstr(const INT8U *str, const INT8U *sub_str, INT8U num);
char *my_strstr(const char *haystack, const char *needle);
char *my_strncat(char *dest, const char *src, size_t n);
int my_sprintf(char* buf, const char* fmt, ...);
int stringToNumber(const char str);
void stringToLower(const char *str);

#endif