#include "ls1x.h"
#include "Config.h"
#include "ls1x_gpio.h"
#include "ls1x_latimer.h"
#include "ls1c102_ptimer.h"
#include "ls1x_uart.h"
#include "queue.h"
#include "esp8266.h"
#include "led.h"
#include "ls1x_string.h"
#include "ls1x_printf.h"
#include "key.h"

int duty;
bool flag = 0;
extern uint8_t Read_Buffer[300];
uint8_t key_value = 0;
extern uint8_t Read_Buffer_2[300];

int stringToNumber(const char str) {
    int result;

    switch(str)
    {
    case '0':result=0;break;
    case '1':result=1;break;
    }

    return result;
}

int main(int arg, char *args[])
{ SystemClockInit(); // 时钟等系统配置
    GPIOInit();        // io配置
    OLED_Init();
    EnableInt(); // 开总中断
    LED_Init();
    Uart0_init(115200); // 串口0初始化，io06 io07
    int i = 0;
    timer_init(100); // set time 0.1ms
    duty = 15; // 初始设置90度
    delay_ms(1000);
    //timer_init(100); // set time 0.1ms

    while(1)
    { 
        /************************************
                    一、接收并解析指令
         ************************************/         
        memset(Read_Buffer, 0, 300);
        int flag=1;
        while(flag)
        {flag=esp8266_receive_data_2();}
        int i;
        int num_cmd[3]={-1,-1,-1};
        int water_cmd=-1;
        char voice_cmd='n';
        for(i=0;i<3;i++)
        {
            num_cmd[i]=stringToNumber(Read_Buffer[i]);        
        }
        voice_cmd=Read_Buffer[i];


        /************************************
                    二、执行指令
         ************************************/     
        switch(voice_cmd)
        {
            case 'a': //开灯
                num_cmd[0]=1;
                break;
            case 'b': //关灯
                num_cmd[0]=0;
                break;
            case 'c': //打开换水           
                num_cmd[1]=1;
                break;
            case 'd': //关闭换水
                num_cmd[1]=0;
                break;
            case 'e': //led模式一
                
                break;
            case 'f': //led模式二

                break;
            case 'g': //打开喂食
                duty = 10;  LED_On(LED1_PIN);
                delay_ms(1000);
                break;
            case 'h': //关闭喂食
                duty = 15;
                LED_Off(LED1_PIN);
                delay_ms(1000);
                break;
            case 'i': //向鱼缸加水
                if(num_cmd[2]==0)    
                water_cmd=0;
                if(num_cmd[2]==1)
                water_cmd=1;
                break;
            case 'j': //从鱼缸放水
                water_cmd=2;
                break;
        }


        if(num_cmd[0]==1)//光照
        {
            gpio_write_pin(GPIO_PIN_17, 1);
        }
        if(num_cmd[0]==0)
        {
            gpio_write_pin(GPIO_PIN_17, 0);
        }
        if(num_cmd[1]==1)//tds
        {
            gpio_write_pin(GPIO_PIN_34, 1);
            gpio_write_pin(GPIO_PIN_37, 1);
        }

        if(num_cmd[1]==0)
        {
            gpio_write_pin(GPIO_PIN_34, 0);
            gpio_write_pin(GPIO_PIN_37, 0);
        }    
        if(water_cmd==0)
        {
            gpio_write_pin(GPIO_PIN_34, 1);
            gpio_write_pin(GPIO_PIN_37, 0);
        }
        if(water_cmd==1)
        {
            gpio_write_pin(GPIO_PIN_34, 0);
            gpio_write_pin(GPIO_PIN_37, 0);
        }
        if(water_cmd==2)
        {
            gpio_write_pin(GPIO_PIN_34, 0);
            gpio_write_pin(GPIO_PIN_37, 1);
        }                      
    }
  
    return 0;
}
