#include "esp8266.h"
#include "Config.h"
#include "ls1x_string.h"
#include "ls1x_printf.h"
#include "ls1x_latimer.h"
#include "queue.h"
#include "led.h"
#include "ls1x_gpio.h"
#include "ls1x_uart.h"

uint8_t wifi_connected = 0;         // ESP8266 连接状态

uint8_t Read_Buffer[DATA_LEN];//设置接收缓冲数组
uint8_t Read_Buffer_2[DATA_LEN];
uint8_t Read_length;
unsigned char esp8266_buf[512];
unsigned short esp8266_cnt = 0, esp8266_cntPre = 0;

int leds[3];
/*
    在进行esp8266试验过程中prinf对应于上位机发送
                           myprintf2(0,#fmt,..)用于发送
*/

// ESP8266 发送命令后，检测接收到的应答
// str：期待的应答结果
// 返回值：0，没有得到期待的应答结果；其他，期待应答结果的位置(str的位置)
char* esp8266_check_cmd(char *str)
{
    char *strx = NULL;

    if(Queue_isEmpty(&Circular_queue)==0)//判断队列是否为空，即判断是否收到数据
    {
        Read_length=Queue_HadUse(&Circular_queue);//返回队列中数据的长度
        {
            memset(Read_Buffer, 0, DATA_LEN);//填充接收缓冲区为0
            Queue_Read(&Circular_queue, Read_Buffer,Read_length);//读取队列缓冲区的值到接收缓冲区
            Read_Buffer[Read_length]='\0';//字符串接收结束符
            //printf("check UART0_RX_BUF:%s\r\n", Read_Buffer);// 打印正确
        }
    }
    strx = pstrstr((const char*)Read_Buffer, (const char*)str);
    return strx;
}

// 向 ESP8266 发送命令
// cmd：发送的命令字符串。
// ack：期待的应答结果，如果为空，则表示不需要等待应答
// waittime：等待时间
// 返回值：0，发送成功(得到了期待的应答结果)；1，发送失败
char esp8266_send_cmd(char *cmd, char *ack, uint16_t waittime)
{
    char res;
    //UART0_RX_STA = 0;
    //printf("cmd:%s\r\n", cmd);
    res=0;
    myprintf2(0,"%s\r\n", cmd);	//发送命令

    if(ack && waittime)		//需要等待应答
    {
        //printf("check UART0_RX_BUF:%s\r\n", Read_Buffer);// 打印正确
        while(--waittime)	//等待倒计时
        {
            delay_ms(1);
            //printf("等待倒计时\r\n");
            if(esp8266_check_cmd(ack))
            {
                printf("ack:%s\r\n", ack);
                break;//得到有效数据
            }
        }
        if(waittime == 0)
        {
            res = 1;
        }
        //else 
            //goto SEND;
        //printf("res:%d\r\n", res);
    }

    return res;
}

// Function to find a substring in a string
const char* myStrstr(const char* haystack, const char* needle) {
    if (!*needle) return haystack; // Empty needle
    for (; *haystack; ++haystack) {
        const char* h = haystack, * n = needle;
        while (*h && *n && *h == *n) {
            h++;
            n++;
        }
        if (!*n) return haystack;
    }
    return NULL;
}

// Function to copy a substring of length len from src to dest
void myStrncpy(char* dest, const char* src, size_t len) {
    while (len > 0 && *src != '\0') {
        *dest++ = *src++;
        len--;
    }
    *dest = '\0';
}
// Function to convert a string to an integer
int myAtoi(const char* str) {
    int result = 0;
    int sign = 1;
    if (*str == '-') {
        sign = -1;
        str++;
    }
    while (*str >= '0' && *str <= '9') {
        result = result * 10 + (*str - '0');
        str++;
    }
    return result * sign;
}

void parseMqttMessage(const char* message, LedState leds[], int maxLeds) {
    // Initialize all LEDs to unknown type and default values
    for (int i = 0; i < maxLeds; i++) {
        leds[i].type = LED_TYPE_UNKNOWN;
        for (int j = 0; j < sizeof(leds[i].value.stringValue); j++) {
            leds[i].value.stringValue[j] = 0;
        }
    }
    
    // Find the start of "params" object
    const char* paramsStart = message+84;
    if (!paramsStart) {
       //printf("Params not found in message.\n");
        
       return;
    }

    // Find the end of "params" object
    const char* paramsEnd = paramsStart;
    while (*paramsEnd != '}') {
        paramsEnd++;
    }
    
    // Extract the content within "params"
    size_t paramsLength = paramsEnd - paramsStart - strlen("\"params\":");
    char params[500]; // Increased buffer size to accommodate more parameters
    strcpy(params, paramsStart + strlen("\"params\":"));
    params[paramsLength] = '\0';

    // Iterate over each possible LED key
    for (int i = 1; i <= maxLeds; i++) {
        char ledKey[10];
        //my_snprintf(ledKey, sizeof(ledKey), "\"led%d\":", i);
        sprintf(ledKey, "\"led%d\":", i);
        const char* ledStart = params + (9*i-8);
        if (ledStart) {
            ledStart += strlen(ledKey); // Move past the key

            if (*ledStart == '\"') { // Check for string
                leds[i - 1].type = LED_TYPE_STRING;
                ledStart++; // Skip the opening quote
                int j = 0;
                while (*ledStart != '\"' && j < sizeof(leds[i - 1].value.stringValue) - 1) {
                    leds[i - 1].value.stringValue[j++] = *ledStart++;
                }
                leds[i - 1].value.stringValue[j] = '\0';
            }
            else { // Assume integer
                leds[i - 1].type = LED_TYPE_INT;
                leds[i - 1].value.intValue = myAtoi(ledStart);
            }
        }
    }
}

void esp8266_init(void)
{
    while(esp8266_send_cmd("AT+CWJAP=\"AP\",\"Zct123456\"\r\n\r\n","WIFI CONNECTED", 2000));
    memset(Read_Buffer, 0, DATA_LEN);
    LED_On(LED1_PIN);
    while(esp8266_send_cmd("AT+MQTTUSERCFG=0,1,\"LC\",\"wc9pi11VD3\",\"version=2018-10-31&res=products%2Fwc9pi11VD3%2Fdevices%2FLC&et=1772972989&method=md5&sign=XsH40sYhwYppXV%2BTk9%2Bo7Q%3D%3D\",0,0,\"\"\r\n\r\n","OK", 2000));
    memset(Read_Buffer, 0, DATA_LEN);
    LED_On(LED2_PIN);
    while(esp8266_send_cmd("AT+MQTTCONN=0,\"mqtts.heclouds.com\",1883,1\r\n\r\n", "OK", 2000));
    memset(Read_Buffer, 0, DATA_LEN);
    LED_On(LED3_PIN);
}
void esp8266_send_data(char* str)
{
    while(esp8266_send_cmd("AT+MQTTSUB=0,\"$sys/wc9pi11VD3/LC/thing/property/post/reply\",1\r\n\r\n", "OK", 2000));
    memset(Read_Buffer, 0, DATA_LEN);
    while(esp8266_send_cmd("AT+MQTTPUBRAW=0,\"$sys/wc9pi11VD3/LC/thing/property/post\",100,0,0\r\n\r\n","OK", 2000));
    memset(Read_Buffer, 0, DATA_LEN);
    while(esp8266_send_cmd(str,"OK", 2000));
    memset(Read_Buffer, 0, DATA_LEN);
}
void esp8266_receive_data_1()
{
    //LED_Off(LED4_PIN);
    while(esp8266_send_cmd("AT+MQTTSUB=0,\"$sys/wc9pi11VD3/LC/thing/property/set\",1\r\n\r\n", "OK", 2000));
    memset(Read_Buffer, 0, DATA_LEN);
}
int esp8266_receive_data_2()
{
    
    if(Queue_isEmpty(&Circular_queue)==0)//判断队列是否为空，即判断是否收到数据
    {
        Read_length=Queue_HadUse(&Circular_queue);//返回队列中数据的长度
        {
            memset(Read_Buffer, 0, DATA_LEN);//填充接收缓冲区为0
            Queue_Read(&Circular_queue, Read_Buffer,Read_length);//读取队列缓冲区的值到接收缓冲区
            Read_Buffer[Read_length]='\0';//字符串接收结束符
        }
        return 0;
    }
    return 1;  
}
void SaveLedStates(LedState leds[], int maxLeds) {
    for (int i = 0; i < maxLeds; i++) {
        switch(i)
        {
            case 0:
                if(leds[i].value.intValue==1)  LED_On(LED1_PIN);
                break;
            case 1:
                if(leds[i].value.intValue==1)  LED_On(LED2_PIN);
                break;
            case 2:
                if(leds[i].value.intValue==1)  LED_On(LED3_PIN);
                break;                
        }
    }
}
void ESP8266_Clear(void)
{

	memset(esp8266_buf, 0, sizeof(esp8266_buf));
	esp8266_cnt = 0;

}