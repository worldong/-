#ifndef USERINC_USERGPIO_H_
#define USERINC_USERGPIO_H_

#include "ls1x_gpio.h"
#include "ls1x_printf.h"
#include "ls1x_clock.h"

void GPIOInit(void);

#endif /* USERINC_USERGPIO_H_ */








