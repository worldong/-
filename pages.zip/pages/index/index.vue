<template>
	<view class="wrap">
		<view class="dev-area">
			
			<view class="dev-cart">
				<view class="">
					<view class="dev-name">温度</view>
					<image class="dev-logo" src="/static/temp.png" mode=""></image>
				</view>
				<view class="dev-data">{{temp}} ℃ </view>
			</view>
			
			<view class="dev-cart">
				<view class="">
					<view class="dev-name">光强</view>
					<image class="dev-logo" src="/static/light.png" mode=""></image>
				</view>
				<view class="dev-data">{{light}}</view>
			</view>
			
			
			<view class="dev-cart">
				<view class="">
					<view class="dev-name">水质</view>
					<image class="dev-logo" src="/static/tds.png" mode=""></image>
				</view>
				<view class="dev-data">{{tds}}</view>
			</view>
			
			<view class="dev-cart">
				<view class="">
					<view class="dev-name">水位</view>
					<image class="dev-logo" src="/static/water.png" mode=""></image>
				</view>
				<view class="dev-data">{{water}}</view>
			</view>
			
<!-- 			<view class="dev-cart">
				<view class="">
					<view class="dev-name">pH</view>
					<image class="dev-logo" src="/static/ph.png" mode=""></image>
				</view>
				<view class="dev-data">{{ph}}</view>
			</view> -->
			
<!-- 			<view class="dev-cart">
				<view class="">
					<view class="dev-name">LED</view>
					<image class="dev-logo" src="/static/led.png" mode=""></image>
				</view>
				<switch :checked="led1" @change="onLed1Switch" />
			</view>
			
			<view class="dev-cart">
				<view class="">
					<view class="dev-name">换水</view>
					<image class="dev-logo" src="/static/pump.png" mode=""></image>
				</view>
				<switch :checked="led2" @change="onLed2Switch" />
			</view>
			
			<view class="dev-cart">
				<view class="">
					<view class="dev-name">喂食</view>
					<image class="dev-logo" src="/static/feed.png" mode=""></image>
				</view>
				<switch :checked="led3" @change="onLed3Switch" />
			</view> -->

		</view>
	</view>

</template>

<script>
	const{createCommonToken}=require('@/key.js')
	export default {
		data() {
			return {				
				temp: '',
				light: '',
				tds: '',
				water: '',
				ph: '',
				led1: '',
				led2: '',
				led3: '',
				token:'',
			}
		},
		onLoad() {
			const params={
				author_key:'Hkrdyzb45tvk6Si0vAMFKTN0QooLjlwL7ZZkMnNdhJ7vdOtSoVdoyNEu0kJFEbU2',
				version:'2022-05-01',
				user_id:'425856',
			}
			this.token = createCommonToken(params);
		},
		onShow() {
			this.fetchDevData();
			setInterval(()=>{
				this.fetchDevData();
			},3000)
		},
		methods: {
			fetchDevData(){
				uni.request({
					url: 'https://iot-api.heclouds.com/thingmodel/query-device-property', 
					method:'GET',
					data: {
						product_id:'wc9pi11VD3',
						device_name:'LC'
					},
					header: {
						'authorization': this.token //自定义请求头信息
					},
					success: (res) => {
						console.log(res.data);
						// this.led1=res.data.data[0].expect_value ==='true'?true:false;
						// this.led2=res.data.data[1].expect_value ==='true'?true:false;
						// this.led3=res.data.data[2].expect_value ==='true'?true:false;
						this.light=res.data.data[0].value;
						//this.ph=res.data.data[4].value;
						this.tds=res.data.data[1].value;
						this.temp=res.data.data[2].value;
						this.water=res.data.data[3].value;
					}
				});
			},
			onLed1Switch(event){
				console.log(event.detail.value);
				let value=event.detail.value;
				uni.request({
					url: 'https://iot-api.heclouds.com/thingmodel/set-device-property', 
					method:'POST',
					data: {
						product_id:'wc9pi11VD3',
						device_name:'LC',
						params:{ "led1": value}
					},
					header: {
						'authorization': this.token //自定义请求头信息
					},
					success: (res) => {
						console.log('LED1'+(value?'ON':'OFF')+'!');

					}
				});			
			},
			onLed2Switch(event){
				console.log(event.detail.value);
				let value=event.detail.value;
				uni.request({
					url: 'https://iot-api.heclouds.com/thingmodel/set-device-property', 
					method:'POST',
					data: {
						product_id:'wc9pi11VD3',
						device_name:'LC',
						params:{ "led2": value}
					},
					header: {
						'authorization': this.token //自定义请求头信息
					},
					success: (res) => {
						console.log('LED2'+(value?'ON':'OFF')+'!');
			
					}
				});			
			},
			onLed3Switch(event){
				console.log(event.detail.value);
				let value=event.detail.value;
				uni.request({
					url: 'https://iot-api.heclouds.com/thingmodel/set-device-property', 
					method:'POST',
					data: {
						product_id:'wc9pi11VD3',
						device_name:'LC',
						params:{ "led3": value}
					},
					header: {
						'authorization': this.token //自定义请求头信息
					},
					success: (res) => {
						console.log('LED3'+(value?'ON':'OFF')+'!');
			
					}
				});			
			},
			onLed4Switch(event){
				console.log(event.detail.value);
				let value=event.detail.value;
				uni.request({
					url: 'https://iot-api.heclouds.com/thingmodel/set-device-property', 
					method:'POST',
					data: {
						product_id:'wc9pi11VD3',
						device_name:'LC',
						params:{ "led4": value}
					},
					header: {
						'authorization': this.token //自定义请求头信息
					},
					success: (res) => {
						console.log('LED4'+(value?'ON':'OFF')+'!');
			
					}
				});			
			},
			onLed5Switch(event){
				console.log(event.detail.value);
				let value=event.detail.value;
				uni.request({
					url: 'https://iot-api.heclouds.com/thingmodel/set-device-property', 
					method:'POST',
					data: {
						product_id:'wc9pi11VD3',
						device_name:'LC',
						params:{ "led5": value}
					},
					header: {
						'authorization': this.token //自定义请求头信息
					},
					success: (res) => {
						console.log('LED5'+(value?'ON':'OFF')+'!');
			
					}
				});			
			},
			onLed6Switch(event){
				console.log(event.detail.value);
				let value=event.detail.value;
				uni.request({
					url: 'https://iot-api.heclouds.com/thingmodel/set-device-property', 
					method:'POST',
					data: {
						product_id:'wc9pi11VD3',
						device_name:'LC',
						params:{ "led6": value}
					},
					header: {
						'authorization': this.token //自定义请求头信息
					},
					success: (res) => {
						console.log('LED6'+(value?'ON':'OFF')+'!');
			
					}
				});			
			}
			
		},
	}
</script>

<style>
	.wrap{
		padding: 30rpx;
	}
	.dev-area {
		display: flex;
		justify-content: space-between;
		flex-wrap: wrap;
		
	}
	.dev-cart {
		height: 150rpx;
		width: 320rpx;
		border-radius: 30rpx;
		margin-top: 30rpx;
		display: flex;
		justify-content: space-around;
		align-items: center;
		box-shadow: 0 0 15rpx #ccc;
	}
	.dev-cart_1 {
		height: 200rpx;
		width: 200rpx;
		border-radius: 30rpx;
		margin-top: 30rpx;
		display: flex;
		justify-content: space-around;
		align-items: center;
		box-shadow: 0 0 15rpx #ccc;
	}
	.dev-name{
		font-size: 20rpx;
		text-align: center;
		color: #6d6d6d
	}
	.dev-name-1{
		font-size: 40rpx;
		text-align: center;
		color: #6d6d6d;
	}
	.dev-logo {
		height: 70rpx;
		width: 70rpx;
		margin-top: 10rpx;
	}
	.dev-data{
		font-size: 50rpx;
		color: #6d6d6d	
	}	

</style>
